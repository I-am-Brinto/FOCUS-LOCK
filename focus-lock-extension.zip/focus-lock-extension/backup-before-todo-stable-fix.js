const phaseTitle = document.getElementById("phaseTitle");
const phasePill = document.getElementById("phasePill");
const timerLabel = document.getElementById("timerLabel");
const timerValue = document.getElementById("timerValue");
const timerHint = document.getElementById("timerHint");

const englishButton = document.getElementById("englishButton");
const banglaButton = document.getElementById("banglaButton");
const daysLabel = document.getElementById("daysLabel");

const coinCount = document.getElementById("coinCount");
const streakCount = document.getElementById("streakCount");

const targetHeading = document.getElementById("targetHeading");
const targetInput = document.getElementById("targetInput");
const targetValue = document.getElementById("targetValue");
const progressFill = document.getElementById("progressFill");
const progressText = document.getElementById("progressText");

const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stopButton");
const settingsButton = document.getElementById("settingsButton");

const todoToggleButton = document.getElementById("todoToggleButton");
const todoPanel = document.getElementById("todoPanel");
const todoCloseButton = document.getElementById("todoCloseButton");
const todoHeading = document.getElementById("todoHeading");
const todoForm = document.getElementById("todoForm");
const todoInput = document.getElementById("todoInput");
const todoAddButton = document.getElementById("todoAddButton");
const todoList = document.getElementById("todoList");
const todoEmpty = document.getElementById("todoEmpty");
const clearCompletedButton = document.getElementById("clearCompletedButton");

const rewardLabels = document.querySelectorAll(".reward-label");

let currentLanguage = "en";

const TEXT = {
  en: {
    phaseIdleTitle: "Ready?",
    phaseSetupTitle: "Open your sites",
    phaseFocusTitle: "Focus in progress",
    phaseBreakTitle: "Break time",

    pillIdle: "IDLE",
    pillSetup: "SETUP",
    pillFocus: "FOCUS",
    pillBreak: "BREAK",

    idleTimerLabel: "Start today's focus session",
    idleTimerHint:
      "After starting, you will have 15 seconds to open the sites you need.",

    setupTimerLabel: "Last 15 seconds before focus starts",
    setupTimerHint:
      "Open every website and tab you need now. New websites will lock after this.",

    focusTimerLabel: "New websites are locked",
    focusTimerHint:
      "Complete today's target to earn one golden coin and extend your streak.",

    breakTimerLabel: "Your break is running",
    breakTimerHint:
      "The session will return to idle automatically when the break ends.",

    goldCoins: "GOLD COINS",
    streak: "STREAK",
    days: "days",
    todoButton: "To-do",

    todayGoal: "Today's goal",
    minutesShort: "min",
    progressComplete: "complete",
    targetAria: "Daily focus target in minutes",

    startFocus: "Start Focus",
    stopSession: "Stop Session",
    settings: "Settings",

    todayTodo: "Today's To-do",
    closeTodo: "Close to-do list",
    todoPanel: "To-do list",
    newTaskPlaceholder: "Write a new task...",
    newTaskAria: "New todo task",
    add: "Add",
    noTasks: "No tasks yet.",
    clearCompleted: "Clear completed",
    completeTask: "Complete task: ",
    deleteTask: "Delete task: "
  },

  bn: {
    phaseIdleTitle: "প্রস্তুত?",
    phaseSetupTitle: "সাইটগুলো খুলে নাও",
    phaseFocusTitle: "Focus চলছে",
    phaseBreakTitle: "Break time",

    pillIdle: "IDLE",
    pillSetup: "SETUP",
    pillFocus: "FOCUS",
    pillBreak: "BREAK",

    idleTimerLabel: "আজকের focus session শুরু করো",
    idleTimerHint:
      "Start চাপার পর দরকারি সব site খোলার জন্য ১৫ সেকেন্ড পাবে।",

    setupTimerLabel: "Focus শুরু হওয়ার আগে শেষ ১৫ সেকেন্ড",
    setupTimerHint:
      "এখন দরকারি সব website ও tab খুলে রাখো। এরপর নতুন website lock হয়ে যাবে।",

    focusTimerLabel: "নতুন website এখন locked",
    focusTimerHint:
      "আজকের target পূরণ করলে একটি golden coin এবং streak reward পাবে।",

    breakTimerLabel: "তোমার break চলছে",
    breakTimerHint:
      "Break শেষ হলে session নিজে থেকেই idle হয়ে যাবে।",

    goldCoins: "গোল্ড কয়েন",
    streak: "স্ট্রিক",
    days: "দিন",
    todoButton: "To-do",

    todayGoal: "আজকের লক্ষ্য",
    minutesShort: "min",
    progressComplete: "complete",
    targetAria: "দৈনিক focus target মিনিটে",

    startFocus: "Focus শুরু করো",
    stopSession: "Session বন্ধ করো",
    settings: "Settings",

    todayTodo: "আজকের To-do",
    closeTodo: "To-do list বন্ধ করো",
    todoPanel: "To-do list",
    newTaskPlaceholder: "নতুন task লিখো...",
    newTaskAria: "নতুন todo task",
    add: "Add",
    noTasks: "এখনো কোনো task নেই।",
    clearCompleted: "Completed task মুছো",
    completeTask: "Task complete করো: ",
    deleteTask: "Task মুছো: "
  }
};

function t() {
  return TEXT[currentLanguage] || TEXT.en;
}

function formatTime(totalSeconds) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function getRemainingSeconds(state) {
  if (!state?.phaseEndsAt) {
    return state?.focusDurationSeconds || 25 * 60;
  }

  return Math.max(0, (state.phaseEndsAt - Date.now()) / 1000);
}

function setPhasePill(phase, label) {
  phasePill.className = `phase-pill ${phase}`;
  phasePill.textContent = label;
}

function createLocalTodoId() {
  return `todo-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

async function readTodosFromStorage() {
  const { todoItems = [] } = await chrome.storage.local.get("todoItems");

  if (!Array.isArray(todoItems)) {
    return [];
  }

  return todoItems
    .filter((item) => item && typeof item.text === "string")
    .map((item) => ({
      id: String(item.id || createLocalTodoId()),
      text: item.text.trim().slice(0, 120),
      done: Boolean(item.done),
      createdAt: Number(item.createdAt) || Date.now()
    }))
    .filter((item) => item.text.length > 0);
}

async function writeTodosToStorage(todoItems) {
  await chrome.storage.local.set({ todoItems });
}

function updateStaticText() {
  const copy = t();

  document.documentElement.lang = currentLanguage === "bn" ? "bn" : "en";

  englishButton.classList.toggle("active", currentLanguage === "en");
  banglaButton.classList.toggle("active", currentLanguage === "bn");

  if (rewardLabels[0]) rewardLabels[0].textContent = copy.goldCoins;
  if (rewardLabels[1]) rewardLabels[1].textContent = copy.streak;

  daysLabel.textContent = copy.days;
  todoToggleButton.textContent = copy.todoButton;
  targetHeading.textContent = copy.todayGoal;
  startButton.textContent = copy.startFocus;
  stopButton.textContent = copy.stopSession;
  settingsButton.textContent = copy.settings;

  todoHeading.textContent = copy.todayTodo;
  todoCloseButton.setAttribute("aria-label", copy.closeTodo);
  todoPanel.setAttribute("aria-label", copy.todoPanel);
  todoInput.placeholder = copy.newTaskPlaceholder;
  todoInput.setAttribute("aria-label", copy.newTaskAria);
  todoAddButton.textContent = copy.add;
  todoEmpty.textContent = copy.noTasks;
  clearCompletedButton.textContent = copy.clearCompleted;
  targetInput.setAttribute("aria-label", copy.targetAria);
}

function renderTodos(todoItems = []) {
  const copy = t();
  const todos = Array.isArray(todoItems) ? todoItems : [];
  const hasTodos = todos.length > 0;
  const hasCompleted = todos.some((item) => item.done);

  todoList.textContent = "";
  todoEmpty.textContent = copy.noTasks;
  clearCompletedButton.textContent = copy.clearCompleted;

  todoEmpty.classList.toggle("hidden", hasTodos);
  clearCompletedButton.classList.toggle("hidden", !hasCompleted);

  for (const item of todos) {
    const li = document.createElement("li");
    li.className = `todo-item${item.done ? " completed" : ""}`;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "todo-check";
    checkbox.checked = Boolean(item.done);
    checkbox.setAttribute("aria-label", `${copy.completeTask}${item.text}`);

    checkbox.addEventListener("change", async () => {
      try {
        const todosFromStorage = await readTodosFromStorage();

        const updatedTodos = todosFromStorage.map((todo) =>
          todo.id === item.id
            ? { ...todo, done: checkbox.checked }
            : todo
        );

        await writeTodosToStorage(updatedTodos);
        renderTodos(updatedTodos);
      } catch (error) {
        console.error("Could not update todo:", error);
        checkbox.checked = !checkbox.checked;
      }
    });

    const text = document.createElement("span");
    text.className = "todo-text";
    text.textContent = item.text;

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "todo-delete";
    deleteButton.textContent = "×";
    deleteButton.setAttribute("aria-label", `${copy.deleteTask}${item.text}`);

    deleteButton.addEventListener("click", async () => {
      try {
        const todosFromStorage = await readTodosFromStorage();

        const updatedTodos = todosFromStorage.filter(
          (todo) => todo.id !== item.id
        );

        await writeTodosToStorage(updatedTodos);
        renderTodos(updatedTodos);
      } catch (error) {
        console.error("Could not delete todo:", error);
      }
    });

    li.append(checkbox, text, deleteButton);
    todoList.appendChild(li);
  }
}

function render(state) {
  currentLanguage = state.language === "bn" ? "bn" : "en";
  updateStaticText();

  const copy = t();
  const remainingSeconds = getRemainingSeconds(state);
  const targetMinutes = Number(state.targetMinutes || 120);
  const completedMinutes = Math.floor(
    Math.max(0, Number(state.dailyFocusSeconds || 0)) / 60
  );

  const progressPercent = Math.min(
    100,
    (completedMinutes / Math.max(1, targetMinutes)) * 100
  );

  targetInput.value = Math.min(
    Number(targetInput.max),
    Math.max(Number(targetInput.min), targetMinutes)
  );

  targetValue.textContent = `${targetMinutes} ${copy.minutesShort}`;
  progressFill.style.width = `${progressPercent}%`;
  progressText.textContent =
    `${completedMinutes} / ${targetMinutes} ${copy.minutesShort} ${copy.progressComplete}`;

  coinCount.textContent = String(Math.max(0, Number(state.coinCount || 0)));
  streakCount.textContent = String(Math.max(0, Number(state.streak || 0)));

  renderTodos(state.todoItems);

  startButton.classList.add("hidden");
  stopButton.classList.add("hidden");

  if (state.phase === "setup") {
    phaseTitle.textContent = copy.phaseSetupTitle;
    setPhasePill("setup", copy.pillSetup);
    timerLabel.textContent = copy.setupTimerLabel;
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent = copy.setupTimerHint;
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "focus") {
    phaseTitle.textContent = copy.phaseFocusTitle;
    setPhasePill("focus", copy.pillFocus);
    timerLabel.textContent = copy.focusTimerLabel;
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent = copy.focusTimerHint;
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "break") {
    phaseTitle.textContent = copy.phaseBreakTitle;
    setPhasePill("break", copy.pillBreak);
    timerLabel.textContent = copy.breakTimerLabel;
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent = copy.breakTimerHint;
    stopButton.classList.remove("hidden");
    return;
  }

  phaseTitle.textContent = copy.phaseIdleTitle;
  setPhasePill("idle", copy.pillIdle);
  timerLabel.textContent = copy.idleTimerLabel;
  timerValue.textContent = formatTime(state.focusDurationSeconds || 25 * 60);
  timerHint.textContent = copy.idleTimerHint;
  startButton.classList.remove("hidden");
}

function setTodoPanelOpen(isOpen) {
  todoPanel.classList.toggle("hidden", !isOpen);
  todoPanel.setAttribute("aria-hidden", String(!isOpen));
  todoToggleButton.setAttribute("aria-expanded", String(isOpen));

  if (isOpen) {
    todoInput.focus();
  }
}

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

async function refresh() {
  try {
    const response = await send("GET_STATE");

    if (response?.ok) {
      render(response.state);
    }
  } catch (error) {
    console.error("Could not load Focus Lock state:", error);
  }
}

async function changeLanguage(language) {
  const response = await send("SET_LANGUAGE", { language });

  if (response?.ok) {
    render(response.state);
  }
}

startButton.addEventListener("click", async () => {
  const response = await send("START_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

stopButton.addEventListener("click", async () => {
  const response = await send("STOP_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

targetInput.addEventListener("input", () => {
  targetValue.textContent = `${targetInput.value} ${t().minutesShort}`;
});

targetInput.addEventListener("change", async () => {
  const response = await send("SET_TARGET", {
    targetMinutes: Number(targetInput.value)
  });

  if (response?.ok) {
    render(response.state);
  }
});

settingsButton.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

englishButton.addEventListener("click", () => {
  changeLanguage("en");
});

banglaButton.addEventListener("click", () => {
  changeLanguage("bn");
});

todoToggleButton.addEventListener("click", () => {
  setTodoPanelOpen(todoPanel.classList.contains("hidden"));
});

todoCloseButton.addEventListener("click", () => {
  setTodoPanelOpen(false);
});

todoForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const taskText = todoInput.value.replace(/\s+/g, " ").trim();

  if (!taskText) {
    todoInput.focus();
    return;
  }

  try {
    const todosFromStorage = await readTodosFromStorage();

    const newTodo = {
      id: createLocalTodoId(),
      text: taskText.slice(0, 120),
      done: false,
      createdAt: Date.now()
    };

    const updatedTodos = [...todosFromStorage, newTodo];

    await writeTodosToStorage(updatedTodos);

    todoInput.value = "";
    renderTodos(updatedTodos);
    todoInput.focus();
  } catch (error) {
    console.error("Could not add todo:", error);
  }
});

clearCompletedButton.addEventListener("click", async () => {
  try {
    const todosFromStorage = await readTodosFromStorage();

    const updatedTodos = todosFromStorage.filter((todo) => !todo.done);

    await writeTodosToStorage(updatedTodos);
    renderTodos(updatedTodos);
  } catch (error) {
    console.error("Could not clear completed todos:", error);
  }
});

refresh();
setInterval(refresh, 1000);
