const PHASE_ALARM = "focus-lock-phase";
const SETUP_SECONDS = 15;

const DEFAULT_STATE = {
  phase: "idle",
  focusDurationSeconds: 25 * 60,
  breakDurationSeconds: 5 * 60,
  targetMinutes: 120,
  completedFocusSeconds: 0,
  setupEndsAt: null,
  phaseEndsAt: null,
  allowedOrigins: [],
  pendingNavigations: {},
  temporaryTabOrigins: {}
};

let reconcilePromise = null;

function isWebUrl(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url);
}

function getOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

function isExtensionUrl(url) {
  return typeof url === "string" && url.startsWith(chrome.runtime.getURL(""));
}

async function ensureDefaultState() {
  const saved = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  const missing = {};

  for (const [key, value] of Object.entries(DEFAULT_STATE)) {
    if (saved[key] === undefined) {
      missing[key] = value;
    }
  }

  if (Object.keys(missing).length > 0) {
    await chrome.storage.local.set(missing);
  }
}

async function getState() {
  const saved = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));

  return {
    ...DEFAULT_STATE,
    ...saved,
    allowedOrigins: Array.isArray(saved.allowedOrigins) ? saved.allowedOrigins : [],
    pendingNavigations: saved.pendingNavigations || {},
    temporaryTabOrigins: saved.temporaryTabOrigins || {}
  };
}

async function updateBadge(state) {
  let text = "";
  let title = "Focus Lock";

  if (state.phase === "setup") {
    text = "15";
    title = "Focus Lock: setup time";
  } else if (state.phase === "focus") {
    text = "LOCK";
    title = "Focus Lock: focus session running";
  } else if (state.phase === "break") {
    text = "BREAK";
    title = "Focus Lock: break time";
  }

  await chrome.action.setBadgeText({ text });
  await chrome.action.setTitle({ title });
}

async function collectAllowedOrigins() {
  const tabs = await chrome.tabs.query({});
  const origins = new Set();

  for (const tab of tabs) {
    if (isWebUrl(tab.url)) {
      const origin = getOrigin(tab.url);
      if (origin) origins.add(origin);
    }
  }

  return [...origins];
}

async function schedulePhaseAlarm(when) {
  await chrome.alarms.clear(PHASE_ALARM);

  if (typeof when === "number" && when > Date.now()) {
    await chrome.alarms.create(PHASE_ALARM, { when });
  }
}

async function finishBreak(state) {
  const nextState = {
    ...state,
    phase: "idle",
    setupEndsAt: null,
    phaseEndsAt: null,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);
  await chrome.alarms.clear(PHASE_ALARM);
  await updateBadge(nextState);

  return nextState;
}

async function beginFocus(state) {
  const focusStartAt = state.phaseEndsAt || Date.now();
  const allowedOrigins = await collectAllowedOrigins();

  const nextState = {
    ...state,
    phase: "focus",
    setupEndsAt: null,
    phaseEndsAt: focusStartAt + state.focusDurationSeconds * 1000,
    allowedOrigins,
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);
  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await updateBadge(nextState);

  return nextState;
}

async function beginBreak(state) {
  const focusEndAt = state.phaseEndsAt || Date.now();

  const nextState = {
    ...state,
    phase: "break",
    setupEndsAt: null,
    phaseEndsAt: focusEndAt + state.breakDurationSeconds * 1000,
    completedFocusSeconds:
      state.completedFocusSeconds + state.focusDurationSeconds,
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);
  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await updateBadge(nextState);

  return nextState;
}

async function reconcileTimer() {
  if (reconcilePromise) return reconcilePromise;

  reconcilePromise = (async () => {
    let state = await getState();

    while (
      ["setup", "focus", "break"].includes(state.phase) &&
      typeof state.phaseEndsAt === "number" &&
      Date.now() >= state.phaseEndsAt
    ) {
      if (state.phase === "setup") {
        state = await beginFocus(state);
      } else if (state.phase === "focus") {
        state = await beginBreak(state);
      } else if (state.phase === "break") {
        state = await finishBreak(state);
      }
    }

    if (
      ["setup", "focus", "break"].includes(state.phase) &&
      typeof state.phaseEndsAt === "number"
    ) {
      await schedulePhaseAlarm(state.phaseEndsAt);
    }

    return state;
  })().finally(() => {
    reconcilePromise = null;
  });

  return reconcilePromise;
}

async function startSession() {
  const current = await getState();

  if (current.phase === "setup" || current.phase === "focus") {
    return current;
  }

  const now = Date.now();

  const nextState = {
    ...current,
    phase: "setup",
    setupEndsAt: now + SETUP_SECONDS * 1000,
    phaseEndsAt: now + SETUP_SECONDS * 1000,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);
  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await updateBadge(nextState);

  return nextState;
}

async function stopSession() {
  const current = await getState();

  const nextState = {
    ...current,
    phase: "idle",
    setupEndsAt: null,
    phaseEndsAt: null,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);
  await chrome.alarms.clear(PHASE_ALARM);
  await updateBadge(nextState);

  return nextState;
}

function canOpenUrl(state, tabId, url) {
  const origin = getOrigin(url);

  if (!origin) return true;
  if (state.allowedOrigins.includes(origin)) return true;
  if (state.temporaryTabOrigins[String(tabId)] === origin) return true;

  return false;
}

async function blockNavigation(tabId, url) {
  const state = await getState();

  if (state.phase !== "focus" || canOpenUrl(state, tabId, url)) {
    return;
  }

  const currentPending = state.pendingNavigations[String(tabId)];

  if (
    currentPending &&
    currentPending.url === url &&
    currentPending.status === "blocked"
  ) {
    return;
  }

  const pendingNavigations = {
    ...state.pendingNavigations,
    [String(tabId)]: {
      url,
      status: "blocked",
      requestedAt: Date.now(),
      unlockAt: null
    }
  };

  await chrome.storage.local.set({ pendingNavigations });

  try {
    await chrome.tabs.update(tabId, {
      url: chrome.runtime.getURL("blocked.html")
    });
  } catch {
    // Tab may have been closed before redirecting.
  }
}

async function requestUrgentAccess(tabId) {
  const state = await getState();
  const item = state.pendingNavigations[String(tabId)];

  if (!item) {
    return { ok: false, reason: "No blocked website found." };
  }

  if (state.phase !== "focus") {
    await chrome.tabs.update(tabId, { url: item.url });
    return { ok: true, openedImmediately: true };
  }

  const unlockAt = Date.now() + 60 * 1000;

  const pendingNavigations = {
    ...state.pendingNavigations,
    [String(tabId)]: {
      ...item,
      status: "countdown",
      unlockAt
    }
  };

  await chrome.storage.local.set({ pendingNavigations });
  await chrome.alarms.create(`focus-lock-urgent-${tabId}`, { when: unlockAt });

  return { ok: true, unlockAt };
}

async function openUrgentAccess(tabId) {
  const state = await getState();
  const item = state.pendingNavigations[String(tabId)];

  if (!item || item.status !== "countdown") return;

  const origin = getOrigin(item.url);
  const temporaryTabOrigins = {
    ...state.temporaryTabOrigins,
    [String(tabId)]: origin
  };

  const pendingNavigations = { ...state.pendingNavigations };
  delete pendingNavigations[String(tabId)];

  await chrome.storage.local.set({
    temporaryTabOrigins,
    pendingNavigations
  });

  try {
    await chrome.tabs.update(tabId, { url: item.url });
  } catch {
    // Tab may have been closed.
  }
}

async function clearTabData(tabId) {
  const state = await getState();

  const pendingNavigations = { ...state.pendingNavigations };
  const temporaryTabOrigins = { ...state.temporaryTabOrigins };

  delete pendingNavigations[String(tabId)];
  delete temporaryTabOrigins[String(tabId)];

  await chrome.storage.local.set({
    pendingNavigations,
    temporaryTabOrigins
  });

  await chrome.alarms.clear(`focus-lock-urgent-${tabId}`);
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaultState()
    .then(reconcileTimer)
    .catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  ensureDefaultState()
    .then(reconcileTimer)
    .catch(console.error);
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === PHASE_ALARM) {
    reconcileTimer().catch(console.error);
    return;
  }

  if (alarm.name.startsWith("focus-lock-urgent-")) {
    const tabId = Number(alarm.name.replace("focus-lock-urgent-", ""));

    if (Number.isInteger(tabId)) {
      openUrgentAccess(tabId).catch(console.error);
    }
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearTabData(tabId).catch(console.error);
});

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  if (!isWebUrl(details.url)) return;
  if (isExtensionUrl(details.url)) return;

  blockNavigation(details.tabId, details.url).catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    await ensureDefaultState();

    if (message.type === "GET_STATE") {
      const state = await reconcileTimer();
      return { ok: true, state };
    }

    if (message.type === "START_SESSION") {
      const state = await startSession();
      return { ok: true, state };
    }

    if (message.type === "STOP_SESSION") {
      const state = await stopSession();
      return { ok: true, state };
    }

    if (message.type === "SET_TARGET") {
      const targetMinutes = Math.max(
        5,
        Math.min(1440, Number(message.targetMinutes) || 120)
      );

      await chrome.storage.local.set({ targetMinutes });
      const state = await getState();

      return { ok: true, state };
    }

    if (message.type === "GET_BLOCKED_SITE") {
      const tabId = sender.tab?.id;

      if (!Number.isInteger(tabId)) {
        return { ok: false, reason: "No active tab found." };
      }

      const state = await getState();
      return {
        ok: true,
        item: state.pendingNavigations[String(tabId)] || null,
        phase: state.phase
      };
    }

    if (message.type === "REQUEST_URGENT_ACCESS") {
      const tabId = sender.tab?.id;

      if (!Number.isInteger(tabId)) {
        return { ok: false, reason: "No active tab found." };
      }

      return requestUrgentAccess(tabId);
    }

    return { ok: false, reason: "Unknown request." };
  })()
    .then(sendResponse)
    .catch((error) => {
      sendResponse({ ok: false, reason: error.message });
    });

  return true;
});

