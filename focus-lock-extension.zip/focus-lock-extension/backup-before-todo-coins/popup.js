const phaseTitle = document.getElementById("phaseTitle");
const phasePill = document.getElementById("phasePill");
const timerLabel = document.getElementById("timerLabel");
const timerValue = document.getElementById("timerValue");
const timerHint = document.getElementById("timerHint");

const targetInput = document.getElementById("targetInput");
const targetValue = document.getElementById("targetValue");
const progressFill = document.getElementById("progressFill");
const progressText = document.getElementById("progressText");

const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stopButton");
const settingsButton = document.getElementById("settingsButton");

let currentState = null;

function formatTime(totalSeconds) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function getRemainingSeconds(state) {
  if (!state?.phaseEndsAt) {
    return state?.focusDurationSeconds || 25 * 60;
  }

  return Math.max(0, (state.phaseEndsAt - Date.now()) / 1000);
}

function getCompletedSeconds(state) {
  let completed = Number(state.completedFocusSeconds || 0);

  if (state.phase === "focus" && state.phaseEndsAt) {
    const total = Number(state.focusDurationSeconds || 25 * 60);
    const remaining = getRemainingSeconds(state);
    completed += Math.max(0, total - remaining);
  }

  return completed;
}

function setPhasePill(phase, label) {
  phasePill.className = `phase-pill ${phase}`;
  phasePill.textContent = label;
}

function render(state) {
  currentState = state;

  const remainingSeconds = getRemainingSeconds(state);
  const targetMinutes = Number(state.targetMinutes || 120);
  const completedMinutes = Math.floor(getCompletedSeconds(state) / 60);
  const progressPercent = Math.min(
    100,
    (completedMinutes / Math.max(1, targetMinutes)) * 100
  );

  targetInput.value = targetMinutes;
  targetValue.textContent = `${targetMinutes} min`;
  progressFill.style.width = `${progressPercent}%`;
  progressText.textContent = `${completedMinutes} / ${targetMinutes} মিনিট complete`;

  startButton.classList.add("hidden");
  stopButton.classList.add("hidden");

  if (state.phase === "setup") {
    phaseTitle.textContent = "সাইটগুলো খুলে নাও";
    setPhasePill("setup", "SETUP");
    timerLabel.textContent = "Focus শুরু হওয়ার আগে শেষ ১৫ সেকেন্ড";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "এখন প্রয়োজনীয় সব website/tab খুলে রাখো। সময় শেষ হলে নতুন website lock হয়ে যাবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "focus") {
    phaseTitle.textContent = "Focus চলছে";
    setPhasePill("focus", "FOCUS");
    timerLabel.textContent = "নতুন website এখন locked";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "জরুরি কিছু লাগলে নতুন site খোলার আগে ১ মিনিট অপেক্ষা করতে হবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "break") {
    phaseTitle.textContent = "Break time";
    setPhasePill("break", "BREAK");
    timerLabel.textContent = "তোমার ৫ মিনিটের বিরতি চলছে";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "Break শেষ হলে session নিজে থেকেই idle হয়ে যাবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  phaseTitle.textContent = "প্রস্তুত?";
  setPhasePill("idle", "IDLE");
  timerLabel.textContent = "আজকের focus session শুরু করো";
  timerValue.textContent = formatTime(state.focusDurationSeconds || 25 * 60);
  timerHint.textContent =
    "Start চাপার পর ১৫ সেকেন্ড পাবে দরকারি সব website খুলে রাখার জন্য।";
  startButton.classList.remove("hidden");
}

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

async function refresh() {
  try {
    const response = await send("GET_STATE");

    if (response?.ok) {
      render(response.state);
    }
  } catch (error) {
    console.error("Could not load Focus Lock state:", error);
  }
}

startButton.addEventListener("click", async () => {
  const response = await send("START_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

stopButton.addEventListener("click", async () => {
  const response = await send("STOP_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

targetInput.addEventListener("input", () => {
  targetValue.textContent = `${targetInput.value} min`;
});

targetInput.addEventListener("change", async () => {
  const response = await send("SET_TARGET", {
    targetMinutes: Number(targetInput.value)
  });

  if (response?.ok) {
    render(response.state);
  }
});

settingsButton.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

refresh();
setInterval(refresh, 1000);
