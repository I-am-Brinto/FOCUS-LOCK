const phaseTitle = document.getElementById("phaseTitle");
const phasePill = document.getElementById("phasePill");
const timerLabel = document.getElementById("timerLabel");
const timerValue = document.getElementById("timerValue");
const timerHint = document.getElementById("timerHint");

const coinCount = document.getElementById("coinCount");
const streakCount = document.getElementById("streakCount");

const targetInput = document.getElementById("targetInput");
const targetValue = document.getElementById("targetValue");
const progressFill = document.getElementById("progressFill");
const progressText = document.getElementById("progressText");

const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stopButton");
const settingsButton = document.getElementById("settingsButton");

const todoToggleButton = document.getElementById("todoToggleButton");
const todoPanel = document.getElementById("todoPanel");
const todoCloseButton = document.getElementById("todoCloseButton");
const todoForm = document.getElementById("todoForm");
const todoInput = document.getElementById("todoInput");
const todoList = document.getElementById("todoList");
const todoEmpty = document.getElementById("todoEmpty");
const clearCompletedButton = document.getElementById("clearCompletedButton");

let currentState = null;

function formatTime(totalSeconds) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function getRemainingSeconds(state) {
  if (!state?.phaseEndsAt) {
    return state?.focusDurationSeconds || 25 * 60;
  }

  return Math.max(0, (state.phaseEndsAt - Date.now()) / 1000);
}

function setPhasePill(phase, label) {
  phasePill.className = `phase-pill ${phase}`;
  phasePill.textContent = label;
}

function renderTodos(todoItems = []) {
  todoList.textContent = "";

  const todos = Array.isArray(todoItems) ? todoItems : [];
  const hasTodos = todos.length > 0;
  const hasCompleted = todos.some((item) => item.done);

  todoEmpty.classList.toggle("hidden", hasTodos);
  clearCompletedButton.classList.toggle("hidden", !hasCompleted);

  for (const item of todos) {
    const li = document.createElement("li");
    li.className = `todo-item${item.done ? " completed" : ""}`;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.className = "todo-check";
    checkbox.checked = Boolean(item.done);
    checkbox.setAttribute("aria-label", `Complete ${item.text}`);

    checkbox.addEventListener("change", async () => {
      const response = await send("TOGGLE_TODO", { id: item.id });

      if (response?.ok) {
        renderTodos(response.todoItems);
      }
    });

    const text = document.createElement("span");
    text.className = "todo-text";
    text.textContent = item.text;

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "todo-delete";
    deleteButton.textContent = "×";
    deleteButton.setAttribute("aria-label", `Delete ${item.text}`);

    deleteButton.addEventListener("click", async () => {
      const response = await send("DELETE_TODO", { id: item.id });

      if (response?.ok) {
        renderTodos(response.todoItems);
      }
    });

    li.append(checkbox, text, deleteButton);
    todoList.appendChild(li);
  }
}

function render(state) {
  currentState = state;

  const remainingSeconds = getRemainingSeconds(state);
  const targetMinutes = Number(state.targetMinutes || 120);
  const completedMinutes = Math.floor(
    Math.max(0, Number(state.dailyFocusSeconds || 0)) / 60
  );

  const progressPercent = Math.min(
    100,
    (completedMinutes / Math.max(1, targetMinutes)) * 100
  );

  targetInput.value = Math.min(
    Number(targetInput.max),
    Math.max(Number(targetInput.min), targetMinutes)
  );

  targetValue.textContent = `${targetMinutes} min`;
  progressFill.style.width = `${progressPercent}%`;
  progressText.textContent = `${completedMinutes} / ${targetMinutes} মিনিট complete`;

  coinCount.textContent = String(Math.max(0, Number(state.coinCount || 0)));
  streakCount.textContent = String(Math.max(0, Number(state.streak || 0)));

  renderTodos(state.todoItems);

  startButton.classList.add("hidden");
  stopButton.classList.add("hidden");

  if (state.phase === "setup") {
    phaseTitle.textContent = "সাইটগুলো খুলে নাও";
    setPhasePill("setup", "SETUP");
    timerLabel.textContent = "Focus শুরু হওয়ার আগে শেষ ১৫ সেকেন্ড";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "এখন প্রয়োজনীয় সব website/tab খুলে রাখো। সময় শেষ হলে নতুন website lock হয়ে যাবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "focus") {
    phaseTitle.textContent = "Focus চলছে";
    setPhasePill("focus", "FOCUS");
    timerLabel.textContent = "নতুন website এখন locked";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "আজকের target পূরণ হলে একটি golden coin এবং streak reward পাবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  if (state.phase === "break") {
    phaseTitle.textContent = "Break time";
    setPhasePill("break", "BREAK");
    timerLabel.textContent = "তোমার ৫ মিনিটের বিরতি চলছে";
    timerValue.textContent = formatTime(remainingSeconds);
    timerHint.textContent =
      "Break শেষ হলে session নিজে থেকেই idle হয়ে যাবে।";
    stopButton.classList.remove("hidden");
    return;
  }

  phaseTitle.textContent = "প্রস্তুত?";
  setPhasePill("idle", "IDLE");
  timerLabel.textContent = "আজকের focus session শুরু করো";
  timerValue.textContent = formatTime(state.focusDurationSeconds || 25 * 60);
  timerHint.textContent =
    "Start চাপার পর ১৫ সেকেন্ড পাবে দরকারি সব website খুলে রাখার জন্য।";
  startButton.classList.remove("hidden");
}

function setTodoPanelOpen(isOpen) {
  todoPanel.classList.toggle("hidden", !isOpen);
  todoPanel.setAttribute("aria-hidden", String(!isOpen));
  todoToggleButton.setAttribute("aria-expanded", String(isOpen));

  if (isOpen) {
    todoInput.focus();
  }
}

async function send(type, payload = {}) {
  return chrome.runtime.sendMessage({ type, ...payload });
}

async function refresh() {
  try {
    const response = await send("GET_STATE");

    if (response?.ok) {
      render(response.state);
    }
  } catch (error) {
    console.error("Could not load Focus Lock state:", error);
  }
}

startButton.addEventListener("click", async () => {
  const response = await send("START_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

stopButton.addEventListener("click", async () => {
  const response = await send("STOP_SESSION");

  if (response?.ok) {
    render(response.state);
  }
});

targetInput.addEventListener("input", () => {
  targetValue.textContent = `${targetInput.value} min`;
});

targetInput.addEventListener("change", async () => {
  const response = await send("SET_TARGET", {
    targetMinutes: Number(targetInput.value)
  });

  if (response?.ok) {
    render(response.state);
  }
});

settingsButton.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});

todoToggleButton.addEventListener("click", () => {
  setTodoPanelOpen(todoPanel.classList.contains("hidden"));
});

todoCloseButton.addEventListener("click", () => {
  setTodoPanelOpen(false);
});

todoForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const text = todoInput.value.trim();

  if (!text) {
    todoInput.focus();
    return;
  }

  const response = await send("ADD_TODO", { text });

  if (response?.ok) {
    todoInput.value = "";
    renderTodos(response.todoItems);
    todoInput.focus();
  }
});

clearCompletedButton.addEventListener("click", async () => {
  const response = await send("CLEAR_COMPLETED_TODOS");

  if (response?.ok) {
    renderTodos(response.todoItems);
  }
});

refresh();
setInterval(refresh, 1000);
