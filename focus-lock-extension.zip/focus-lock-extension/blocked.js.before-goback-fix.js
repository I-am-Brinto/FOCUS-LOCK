const blockedTitle = document.getElementById("blockedTitle");
const siteText = document.getElementById("siteText");
const countdownBox = document.getElementById("countdownBox");
const countdownTitle = document.getElementById("countdownTitle");
const countdownValue = document.getElementById("countdownValue");
const countdownHint = document.getElementById("countdownHint");
const buttonArea = document.getElementById("buttonArea");
const urgentButton = document.getElementById("urgentButton");
const backButton = document.getElementById("backButton");
const statusText = document.getElementById("statusText");

let currentLanguage = "en";

const TEXT = {
  en: {
    title: "New websites are locked right now",
    blockedSite: (host) => `${host} is locked during your focus session.`,
    genericBlocked: "This website is blocked until your focus session ends.",
    urgentTitle: "Urgent access is unlocking",
    urgentHint: "The site will open automatically when time ends.",
    urgentButton: "Yes, it is urgent — wait 1 minute",
    backButton: "Go back",
    status: "Only request access when this site is genuinely necessary.",
    countdownStarted: "Your 1-minute countdown has started.",
    opening: "Opening website...",
    noBlockedSite: "No blocked website was found. Close this tab and try again.",
    noAccess: "Urgent access could not be started. Try again."
  },
  bn: {
    title: "এখন নতুন website খোলা যাবে না",
    blockedSite: (host) => `${host} focus session চলাকালে lock করা হয়েছে।`,
    genericBlocked: "এই website-টি focus session শেষ না হওয়া পর্যন্ত lock করা হয়েছে।",
    urgentTitle: "জরুরি access চালু হচ্ছে",
    urgentHint: "সময় শেষ হলে site নিজে থেকেই খুলবে।",
    urgentButton: "হ্যাঁ, জরুরি — ১ মিনিট অপেক্ষা করব",
    backButton: "ফিরে যাও",
    status: "সত্যিই দরকার হলেই শুধু access নাও।",
    countdownStarted: "১ মিনিটের countdown শুরু হয়েছে।",
    opening: "Website খোলা হচ্ছে...",
    noBlockedSite: "কোনো blocked website পাওয়া যায়নি। এই tab বন্ধ করে আবার চেষ্টা করো।",
    noAccess: "Urgent access চালু করা যায়নি। আবার চেষ্টা করো।"
  }
};

function t() {
  return TEXT[currentLanguage] || TEXT.en;
}

function applyLanguage() {
  const copy = t();

  document.documentElement.lang = currentLanguage === "bn" ? "bn" : "en";
  blockedTitle.textContent = copy.title;
  countdownTitle.textContent = copy.urgentTitle;
  countdownHint.textContent = copy.urgentHint;
  urgentButton.textContent = copy.urgentButton;
  backButton.textContent = copy.backButton;
}

function formatTime(totalSeconds) {
  const seconds = Math.max(0, Math.ceil(totalSeconds));
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;

  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function showCountdown(unlockAt) {
  countdownBox.classList.remove("hidden");
  buttonArea.classList.add("hidden");

  const tick = () => {
    const remainingSeconds = (unlockAt - Date.now()) / 1000;

    if (remainingSeconds <= 0) {
      countdownValue.textContent = "00:00";
      statusText.textContent = t().opening;
      return;
    }

    countdownValue.textContent = formatTime(remainingSeconds);
  };

  tick();
  setInterval(tick, 1000);
}

async function loadBlockedSite() {
  const [{ language }, response] = await Promise.all([
    chrome.storage.local.get("language"),
    chrome.runtime.sendMessage({ type: "GET_BLOCKED_SITE" })
  ]);

  currentLanguage = language === "bn" ? "bn" : "en";
  applyLanguage();

  if (!response?.ok || !response.item) {
    siteText.textContent = t().noBlockedSite;
    urgentButton.disabled = true;
    return;
  }

  try {
    const url = new URL(response.item.url);
    siteText.textContent = t().blockedSite(url.hostname);
  } catch {
    siteText.textContent = t().genericBlocked;
  }

  statusText.textContent = t().status;

  if (response.item.status === "countdown" && response.item.unlockAt) {
    showCountdown(response.item.unlockAt);
  }
}

urgentButton.addEventListener("click", async () => {
  const response = await chrome.runtime.sendMessage({
    type: "REQUEST_URGENT_ACCESS"
  });

  if (!response?.ok) {
    statusText.textContent = response?.reason || t().noAccess;
    return;
  }

  if (response.openedImmediately) {
    statusText.textContent = t().opening;
    return;
  }

  statusText.textContent = t().countdownStarted;
  showCountdown(response.unlockAt);
});

backButton.addEventListener("click", () => {
  if (window.history.length > 1) {
    window.history.back();
    return;
  }

  window.close();
});

loadBlockedSite().catch((error) => {
  console.error(error);
  siteText.textContent = t().genericBlocked;
});
