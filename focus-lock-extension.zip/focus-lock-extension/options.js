const focusDurationInput = document.getElementById("focusDuration");
const breakDurationInput = document.getElementById("breakDuration");
const targetMinutesInput = document.getElementById("targetMinutes");
const saveButton = document.getElementById("saveButton");
const statusText = document.getElementById("statusText");

const settingsTitle = document.getElementById("settingsTitle");
const introText = document.getElementById("introText");
const focusLabel = document.getElementById("focusLabel");
const breakLabel = document.getElementById("breakLabel");
const targetLabel = document.getElementById("targetLabel");

let currentLanguage = "en";

const TEXT = {
  en: {
    title: "Settings",
    intro: "Customize your Pomodoro durations and daily goal.",
    focus: "Focus duration (minutes)",
    break: "Break duration (minutes)",
    target: "Daily focus target (minutes)",
    save: "Save settings",
    saved: "Settings saved.",
    loadError: "Could not load settings."
  },
  bn: {
    title: "Settings",
    intro: "Pomodoro সময় ও daily target নিজের মতো করে সেট করো।",
    focus: "Focus duration (minutes)",
    break: "Break duration (minutes)",
    target: "Daily focus target (minutes)",
    save: "Settings save করো",
    saved: "Settings saved.",
    loadError: "Settings load করা যায়নি।"
  }
};

function t() {
  return TEXT[currentLanguage] || TEXT.en;
}

function applyLanguage() {
  const copy = t();

  document.documentElement.lang = currentLanguage === "bn" ? "bn" : "en";
  document.title = `Focus Lock ${copy.title}`;

  settingsTitle.textContent = copy.title;
  introText.textContent = copy.intro;
  focusLabel.textContent = copy.focus;
  breakLabel.textContent = copy.break;
  targetLabel.textContent = copy.target;
  saveButton.textContent = copy.save;
}

function clamp(value, min, max, fallback) {
  const number = Number(value);

  if (!Number.isFinite(number)) {
    return fallback;
  }

  return Math.min(max, Math.max(min, Math.round(number)));
}

async function loadSettings() {
  const settings = await chrome.storage.local.get([
    "focusDurationSeconds",
    "breakDurationSeconds",
    "targetMinutes",
    "language"
  ]);

  currentLanguage = settings.language === "bn" ? "bn" : "en";
  applyLanguage();

  focusDurationInput.value = Math.round(
    (settings.focusDurationSeconds || 25 * 60) / 60
  );

  breakDurationInput.value = Math.round(
    (settings.breakDurationSeconds || 5 * 60) / 60
  );

  targetMinutesInput.value = settings.targetMinutes || 120;
}

saveButton.addEventListener("click", async () => {
  const focusMinutes = clamp(focusDurationInput.value, 1, 120, 25);
  const breakMinutes = clamp(breakDurationInput.value, 1, 60, 5);
  const targetMinutes = clamp(targetMinutesInput.value, 5, 1440, 120);

  await chrome.storage.local.set({
    focusDurationSeconds: focusMinutes * 60,
    breakDurationSeconds: breakMinutes * 60,
    targetMinutes
  });

  focusDurationInput.value = focusMinutes;
  breakDurationInput.value = breakMinutes;
  targetMinutesInput.value = targetMinutes;

  statusText.textContent = t().saved;

  setTimeout(() => {
    statusText.textContent = "";
  }, 2200);
});

loadSettings().catch((error) => {
  console.error(error);
  statusText.textContent = t().loadError;
});
