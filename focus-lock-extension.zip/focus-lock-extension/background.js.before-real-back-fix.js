const PHASE_ALARM = "focus-lock-phase";
const DAILY_GOAL_ALARM = "focus-lock-daily-goal";
const SETUP_SECONDS = 15;
const MAX_TODOS = 50;

const DEFAULT_STATE = {
  phase: "idle",
  focusDurationSeconds: 25 * 60,
  breakDurationSeconds: 5 * 60,
  targetMinutes: 120,
  completedFocusSeconds: 0,

  dailyFocusSeconds: 0,
  dailyDateKey: null,
  coinCount: 0,
  streak: 0,
  lastTargetCompletedDate: null,

  todoItems: [],
  language: "en",

  setupEndsAt: null,
  phaseEndsAt: null,
  focusProgressCursorAt: null,

  allowedOrigins: [],
  pendingNavigations: {},
  temporaryTabOrigins: {},
  lastSafeUrls: {}
};

let reconcilePromise = null;

function isWebUrl(url) {
  return typeof url === "string" && /^https?:\/\//i.test(url);
}

function getOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return null;
  }
}

function isExtensionUrl(url) {
  return typeof url === "string" && url.startsWith(chrome.runtime.getURL(""));
}

function getLocalDateKey(timestamp = Date.now()) {
  const date = new Date(timestamp);

  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(
    2,
    "0"
  )}-${String(date.getDate()).padStart(2, "0")}`;
}

function getDateFromKey(dateKey) {
  const [year, month, day] = String(dateKey || "")
    .split("-")
    .map(Number);

  if (!year || !month || !day) {
    return new Date();
  }

  return new Date(year, month - 1, day);
}

function getPreviousDateKey(dateKey) {
  const date = getDateFromKey(dateKey);
  date.setDate(date.getDate() - 1);

  return getLocalDateKey(date.getTime());
}

function getDayBounds(dateKey) {
  const start = getDateFromKey(dateKey);
  start.setHours(0, 0, 0, 0);

  const end = new Date(start);
  end.setDate(end.getDate() + 1);

  return {
    startAt: start.getTime(),
    endAt: end.getTime()
  };
}

function getFocusDuration(state) {
  return Math.max(60, Number(state.focusDurationSeconds) || 25 * 60);
}

function getBreakDuration(state) {
  return Math.max(60, Number(state.breakDurationSeconds) || 5 * 60);
}

function normalizeTodos(value) {
  if (!Array.isArray(value)) return [];

  return value
    .filter((item) => item && typeof item.text === "string")
    .slice(0, MAX_TODOS)
    .map((item) => ({
      id: String(item.id || `${Date.now()}-${Math.random()}`),
      text: item.text.slice(0, 120),
      done: Boolean(item.done),
      createdAt: Number(item.createdAt) || Date.now()
    }));
}

function createTodoId() {
  if (typeof crypto?.randomUUID === "function") {
    return crypto.randomUUID();
  }

  return `${Date.now().toString(36)}-${Math.random()
    .toString(36)
    .slice(2)}`;
}

async function ensureDefaultState() {
  const saved = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));
  const missing = {};

  for (const [key, value] of Object.entries(DEFAULT_STATE)) {
    if (saved[key] === undefined) {
      missing[key] = value;
    }
  }

  if (Object.keys(missing).length > 0) {
    await chrome.storage.local.set(missing);
  }
}

async function getState() {
  const saved = await chrome.storage.local.get(Object.keys(DEFAULT_STATE));

  return {
    ...DEFAULT_STATE,
    ...saved,

    focusDurationSeconds: getFocusDuration({
      ...DEFAULT_STATE,
      ...saved
    }),

    breakDurationSeconds: getBreakDuration({
      ...DEFAULT_STATE,
      ...saved
    }),

    targetMinutes: Math.max(
      5,
      Math.min(1440, Number(saved.targetMinutes) || 120)
    ),

    dailyFocusSeconds: Math.max(0, Number(saved.dailyFocusSeconds) || 0),
    completedFocusSeconds: Math.max(
      0,
      Number(saved.completedFocusSeconds) || 0
    ),

    coinCount: Math.max(0, Number(saved.coinCount) || 0),
    streak: Math.max(0, Number(saved.streak) || 0),

    todoItems: normalizeTodos(saved.todoItems),

    allowedOrigins: Array.isArray(saved.allowedOrigins)
      ? saved.allowedOrigins
      : [],

    pendingNavigations: saved.pendingNavigations || {},
    temporaryTabOrigins: saved.temporaryTabOrigins || {},
    lastSafeUrls: saved.lastSafeUrls || {}
  };
}

async function ensureDailyState() {
  let state = await getState();
  const today = getLocalDateKey();

  if (state.dailyDateKey !== today) {
    await chrome.storage.local.set({
      dailyDateKey: today,
      dailyFocusSeconds: 0
    });

    state = {
      ...state,
      dailyDateKey: today,
      dailyFocusSeconds: 0
    };
  }

  return state;
}

async function updateBadge(state) {
  let text = "";
  let title = "Focus Lock";

  if (state.phase === "setup") {
    text = "15";
    title = "Focus Lock: setup time";
  } else if (state.phase === "focus") {
    text = "LOCK";
    title = "Focus Lock: focus session running";
  } else if (state.phase === "break") {
    text = "BREAK";
    title = "Focus Lock: break time";
  }

  await chrome.action.setBadgeText({ text });
  await chrome.action.setTitle({ title });
}

async function collectAllowedOrigins() {
  const tabs = await chrome.tabs.query({});
  const origins = new Set();

  for (const tab of tabs) {
    if (isWebUrl(tab.url)) {
      const origin = getOrigin(tab.url);

      if (origin) origins.add(origin);
    }
  }

  return [...origins];
}

async function schedulePhaseAlarm(when) {
  await chrome.alarms.clear(PHASE_ALARM);

  if (typeof when === "number" && when > Date.now()) {
    await chrome.alarms.create(PHASE_ALARM, { when });
  }
}

async function scheduleDailyGoalAlarm(state) {
  await chrome.alarms.clear(DAILY_GOAL_ALARM);

  if (state.phase !== "focus" || typeof state.phaseEndsAt !== "number") {
    return;
  }

  const targetSeconds = state.targetMinutes * 60;
  const remainingSeconds = targetSeconds - state.dailyFocusSeconds;

  if (remainingSeconds <= 0) {
    return;
  }

  const when = Date.now() + remainingSeconds * 1000;

  if (when <= state.phaseEndsAt) {
    await chrome.alarms.create(DAILY_GOAL_ALARM, { when });
  }
}

async function evaluateDailyGoal(state) {
  const targetSeconds = state.targetMinutes * 60;

  if (state.dailyFocusSeconds + 0.001 < targetSeconds) {
    return state;
  }

  if (state.lastTargetCompletedDate === state.dailyDateKey) {
    return state;
  }

  const yesterday = getPreviousDateKey(state.dailyDateKey);

  const streak =
    state.lastTargetCompletedDate === yesterday ? state.streak + 1 : 1;

  const nextState = {
    ...state,
    coinCount: state.coinCount + 1,
    streak,
    lastTargetCompletedDate: state.dailyDateKey
  };

  await chrome.storage.local.set({
    coinCount: nextState.coinCount,
    streak: nextState.streak,
    lastTargetCompletedDate: nextState.lastTargetCompletedDate
  });

  return nextState;
}

async function syncActiveFocusProgress(state, now = Date.now()) {
  if (state.phase !== "focus" || typeof state.phaseEndsAt !== "number") {
    return state;
  }

  const focusDurationMs = getFocusDuration(state) * 1000;
  const focusStartAt = state.phaseEndsAt - focusDurationMs;

  const cursorAt = Math.max(
    focusStartAt,
    Number(state.focusProgressCursorAt) || focusStartAt
  );

  const endAt = Math.min(now, state.phaseEndsAt);

  if (endAt <= cursorAt) {
    return state;
  }

  const { startAt: dayStartAt, endAt: dayEndAt } = getDayBounds(
    state.dailyDateKey
  );

  const countedMs = Math.max(
    0,
    Math.min(endAt, dayEndAt) - Math.max(cursorAt, dayStartAt)
  );

  const nextState = {
    ...state,
    dailyFocusSeconds: state.dailyFocusSeconds + countedMs / 1000,
    focusProgressCursorAt: endAt
  };

  await chrome.storage.local.set({
    dailyFocusSeconds: nextState.dailyFocusSeconds,
    focusProgressCursorAt: nextState.focusProgressCursorAt
  });

  return evaluateDailyGoal(nextState);
}

async function finishBreak(state) {
  const nextState = {
    ...state,
    phase: "idle",
    setupEndsAt: null,
    phaseEndsAt: null,
    focusProgressCursorAt: null,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);

  await chrome.alarms.clear(PHASE_ALARM);
  await chrome.alarms.clear(DAILY_GOAL_ALARM);

  await updateBadge(nextState);

  return nextState;
}

async function beginFocus(state) {
  const focusStartAt = state.phaseEndsAt || Date.now();
  const allowedOrigins = await collectAllowedOrigins();

  const nextState = {
    ...state,
    phase: "focus",
    setupEndsAt: null,
    phaseEndsAt: focusStartAt + getFocusDuration(state) * 1000,
    focusProgressCursorAt: focusStartAt,
    allowedOrigins,
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);

  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await scheduleDailyGoalAlarm(nextState);
  await updateBadge(nextState);

  return nextState;
}

async function beginBreak(state) {
  const focusEndAt = state.phaseEndsAt || Date.now();

  const nextState = {
    ...state,
    phase: "break",
    setupEndsAt: null,
    phaseEndsAt: focusEndAt + getBreakDuration(state) * 1000,
    focusProgressCursorAt: null,
    completedFocusSeconds:
      state.completedFocusSeconds + getFocusDuration(state),
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);

  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await chrome.alarms.clear(DAILY_GOAL_ALARM);
  await updateBadge(nextState);

  return nextState;
}

async function reconcileTimer() {
  if (reconcilePromise) return reconcilePromise;

  reconcilePromise = (async () => {
    let state = await ensureDailyState();

    state = await syncActiveFocusProgress(state);

    while (
      ["setup", "focus", "break"].includes(state.phase) &&
      typeof state.phaseEndsAt === "number" &&
      Date.now() >= state.phaseEndsAt
    ) {
      if (state.phase === "setup") {
        state = await beginFocus(state);
      } else if (state.phase === "focus") {
        state = await syncActiveFocusProgress(state, state.phaseEndsAt);
        state = await beginBreak(state);
      } else if (state.phase === "break") {
        state = await finishBreak(state);
      }
    }

    if (
      ["setup", "focus", "break"].includes(state.phase) &&
      typeof state.phaseEndsAt === "number"
    ) {
      await schedulePhaseAlarm(state.phaseEndsAt);
    }

    if (state.phase === "focus") {
      await scheduleDailyGoalAlarm(state);
    }

    return state;
  })().finally(() => {
    reconcilePromise = null;
  });

  return reconcilePromise;
}

async function startSession() {
  const current = await ensureDailyState();

  if (current.phase === "setup" || current.phase === "focus") {
    return current;
  }

  const now = Date.now();

  const nextState = {
    ...current,
    phase: "setup",
    setupEndsAt: now + SETUP_SECONDS * 1000,
    phaseEndsAt: now + SETUP_SECONDS * 1000,
    focusProgressCursorAt: null,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);

  await schedulePhaseAlarm(nextState.phaseEndsAt);
  await chrome.alarms.clear(DAILY_GOAL_ALARM);
  await updateBadge(nextState);

  return nextState;
}

async function stopSession() {
  let current = await ensureDailyState();

  current = await syncActiveFocusProgress(current);

  const nextState = {
    ...current,
    phase: "idle",
    setupEndsAt: null,
    phaseEndsAt: null,
    focusProgressCursorAt: null,
    allowedOrigins: [],
    pendingNavigations: {},
    temporaryTabOrigins: {}
  };

  await chrome.storage.local.set(nextState);

  await chrome.alarms.clear(PHASE_ALARM);
  await chrome.alarms.clear(DAILY_GOAL_ALARM);

  await updateBadge(nextState);

  return nextState;
}

function canOpenUrl(state, tabId, url) {
  const origin = getOrigin(url);

  if (!origin) return true;
  if (state.allowedOrigins.includes(origin)) return true;
  if (state.temporaryTabOrigins[String(tabId)] === origin) return true;

  return false;
}

async function rememberSafeUrl(tabId, url) {
  if (!isWebUrl(url)) return;

  const state = await getState();

  if (state.phase === "focus" && !canOpenUrl(state, tabId, url)) {
    return;
  }

  const lastSafeUrls = {
    ...state.lastSafeUrls,
    [String(tabId)]: url
  };

  await chrome.storage.local.set({ lastSafeUrls });
}

async function getReturnUrlForBlockedNavigation(state, tabId, targetUrl) {
  const savedUrl = state.lastSafeUrls[String(tabId)];

  if (
    isWebUrl(savedUrl) &&
    savedUrl !== targetUrl &&
    canOpenUrl(state, tabId, savedUrl)
  ) {
    return savedUrl;
  }

  try {
    const tab = await chrome.tabs.get(tabId);

    if (
      isWebUrl(tab.url) &&
      tab.url !== targetUrl &&
      canOpenUrl(state, tabId, tab.url)
    ) {
      return tab.url;
    }
  } catch {
    // The tab may already be closed.
  }

  return null;
}

async function blockNavigation(tabId, url) {
  const state = await reconcileTimer();

  if (state.phase !== "focus" || canOpenUrl(state, tabId, url)) {
    return;
  }

  const currentPending = state.pendingNavigations[String(tabId)];

  if (
    currentPending &&
    currentPending.url === url &&
    currentPending.status === "blocked"
  ) {
    return;
  }

  const returnUrl = await getReturnUrlForBlockedNavigation(
    state,
    tabId,
    url
  );

  const pendingNavigations = {
    ...state.pendingNavigations,
    [String(tabId)]: {
      url,
      returnUrl,
      status: "blocked",
      requestedAt: Date.now(),
      unlockAt: null
    }
  };

  await chrome.storage.local.set({ pendingNavigations });

  try {
    await chrome.tabs.update(tabId, {
      url: chrome.runtime.getURL("blocked.html")
    });
  } catch {
    // Tab may have been closed before redirecting.
  }
}

async function requestUrgentAccess(tabId) {
  const state = await reconcileTimer();

  const item = state.pendingNavigations[String(tabId)];

  if (!item) {
    return { ok: false, reason: "No blocked website found." };
  }

  if (state.phase !== "focus") {
    await chrome.tabs.update(tabId, { url: item.url });
    return { ok: true, openedImmediately: true };
  }

  const unlockAt = Date.now() + 60 * 1000;

  const pendingNavigations = {
    ...state.pendingNavigations,
    [String(tabId)]: {
      ...item,
      status: "countdown",
      unlockAt
    }
  };

  await chrome.storage.local.set({ pendingNavigations });

  await chrome.alarms.create(`focus-lock-urgent-${tabId}`, {
    when: unlockAt
  });

  return { ok: true, unlockAt };
}

async function openUrgentAccess(tabId) {
  const state = await getState();
  const item = state.pendingNavigations[String(tabId)];

  if (!item || item.status !== "countdown") return;

  const origin = getOrigin(item.url);

  const temporaryTabOrigins = {
    ...state.temporaryTabOrigins,
    [String(tabId)]: origin
  };

  const pendingNavigations = { ...state.pendingNavigations };

  delete pendingNavigations[String(tabId)];

  await chrome.storage.local.set({
    temporaryTabOrigins,
    pendingNavigations
  });

  try {
    await chrome.tabs.update(tabId, { url: item.url });
  } catch {
    // Tab may have been closed.
  }
}

async function returnFromBlocked(tabId) {
  const state = await getState();

  const googleUrl = "https://www.google.com/";
  const googleOrigin = "https://www.google.com";

  const pendingNavigations = {
    ...state.pendingNavigations
  };

  const temporaryTabOrigins = {
    ...state.temporaryTabOrigins
  };

  const lastSafeUrls = {
    ...state.lastSafeUrls
  };

  delete pendingNavigations[String(tabId)];
  delete temporaryTabOrigins[String(tabId)];
  delete lastSafeUrls[String(tabId)];

  try {
    const newTab = await chrome.tabs.create({
      active: true,
      url: "about:blank"
    });

    temporaryTabOrigins[String(newTab.id)] = googleOrigin;
    lastSafeUrls[String(newTab.id)] = googleUrl;

    await chrome.storage.local.set({
      pendingNavigations,
      temporaryTabOrigins,
      lastSafeUrls
    });

    await chrome.tabs.update(newTab.id, {
      url: googleUrl
    });

    await chrome.tabs.remove(tabId);

    return { ok: true, action: "opened-google" };
  } catch (error) {
    console.error("Could not open Google home:", error);

    return {
      ok: false,
      reason: "Could not open Google home."
    };
  }
}

async function clearTabData(tabId) {
  const state = await getState();

  const pendingNavigations = { ...state.pendingNavigations };
  const temporaryTabOrigins = { ...state.temporaryTabOrigins };
  const lastSafeUrls = { ...state.lastSafeUrls };

  delete pendingNavigations[String(tabId)];
  delete temporaryTabOrigins[String(tabId)];
  delete lastSafeUrls[String(tabId)];

  await chrome.storage.local.set({
    pendingNavigations,
    temporaryTabOrigins,
    lastSafeUrls
  });

  await chrome.alarms.clear(`focus-lock-urgent-${tabId}`);
}

async function addTodo(text) {
  const state = await getState();

  const cleanText = String(text || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120);

  if (!cleanText) {
    return { ok: false, reason: "Write a task first." };
  }

  if (state.todoItems.length >= MAX_TODOS) {
    return { ok: false, reason: "Todo list is full." };
  }

  const todoItems = [
    {
      id: createTodoId(),
      text: cleanText,
      done: false,
      createdAt: Date.now()
    },
    ...state.todoItems
  ];

  await chrome.storage.local.set({ todoItems });

  return { ok: true, todoItems };
}

async function toggleTodo(id) {
  const state = await getState();

  const todoItems = state.todoItems.map((item) =>
    item.id === id ? { ...item, done: !item.done } : item
  );

  await chrome.storage.local.set({ todoItems });

  return { ok: true, todoItems };
}

async function deleteTodo(id) {
  const state = await getState();

  const todoItems = state.todoItems.filter((item) => item.id !== id);

  await chrome.storage.local.set({ todoItems });

  return { ok: true, todoItems };
}

async function clearCompletedTodos() {
  const state = await getState();

  const todoItems = state.todoItems.filter((item) => !item.done);

  await chrome.storage.local.set({ todoItems });

  return { ok: true, todoItems };
}

chrome.runtime.onInstalled.addListener(() => {
  ensureDefaultState()
    .then(reconcileTimer)
    .catch(console.error);
});

chrome.runtime.onStartup.addListener(() => {
  ensureDefaultState()
    .then(reconcileTimer)
    .catch(console.error);
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === PHASE_ALARM) {
    reconcileTimer().catch(console.error);
    return;
  }

  if (alarm.name === DAILY_GOAL_ALARM) {
    reconcileTimer().catch(console.error);
    return;
  }

  if (alarm.name.startsWith("focus-lock-urgent-")) {
    const tabId = Number(alarm.name.replace("focus-lock-urgent-", ""));

    if (Number.isInteger(tabId)) {
      openUrgentAccess(tabId).catch(console.error);
    }
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;
  if (!isWebUrl(tab.url)) return;

  rememberSafeUrl(tabId, tab.url).catch(console.error);
});

chrome.tabs.onRemoved.addListener((tabId) => {
  clearTabData(tabId).catch(console.error);
});

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  if (details.frameId !== 0) return;
  if (!isWebUrl(details.url)) return;
  if (isExtensionUrl(details.url)) return;

  blockNavigation(details.tabId, details.url).catch(console.error);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    await ensureDefaultState();

    if (message.type === "GET_STATE") {
      const state = await reconcileTimer();
      return { ok: true, state };
    }

    if (message.type === "START_SESSION") {
      const state = await startSession();
      return { ok: true, state };
    }

    if (message.type === "STOP_SESSION") {
      const state = await stopSession();
      return { ok: true, state };
    }

    if (message.type === "SET_TARGET") {
      const targetMinutes = Math.max(
        5,
        Math.min(1440, Number(message.targetMinutes) || 120)
      );

      await chrome.storage.local.set({ targetMinutes });

      let state = await ensureDailyState();

      state = {
        ...state,
        targetMinutes
      };

      state = await syncActiveFocusProgress(state);
      state = await evaluateDailyGoal(state);

      if (state.phase === "focus") {
        await scheduleDailyGoalAlarm(state);
      }

      return { ok: true, state };
    }

    if (message.type === "SET_LANGUAGE") {
      const language = message.language === "bn" ? "bn" : "en";

      await chrome.storage.local.set({ language });

      const state = await getState();

      return { ok: true, state };
    }

    if (message.type === "GET_TODOS") {
      const state = await getState();
      return { ok: true, todoItems: state.todoItems };
    }

    if (message.type === "ADD_TODO") {
      return addTodo(message.text);
    }

    if (message.type === "TOGGLE_TODO") {
      return toggleTodo(String(message.id || ""));
    }

    if (message.type === "DELETE_TODO") {
      return deleteTodo(String(message.id || ""));
    }

    if (message.type === "CLEAR_COMPLETED_TODOS") {
      return clearCompletedTodos();
    }

    if (message.type === "RETURN_FROM_BLOCKED") {
      const tabId = Number.isInteger(message.tabId)
        ? message.tabId
        : sender.tab?.id;

      if (!Number.isInteger(tabId)) {
        return { ok: false, reason: "No active tab found." };
      }

      return returnFromBlocked(tabId);
    }

    if (message.type === "GET_BLOCKED_SITE") {
      const tabId = sender.tab?.id;

      if (!Number.isInteger(tabId)) {
        return { ok: false, reason: "No active tab found." };
      }

      const state = await getState();

      return {
        ok: true,
        item: state.pendingNavigations[String(tabId)] || null,
        phase: state.phase
      };
    }

    if (message.type === "REQUEST_URGENT_ACCESS") {
      const tabId = sender.tab?.id;

      if (!Number.isInteger(tabId)) {
        return { ok: false, reason: "No active tab found." };
      }

      return requestUrgentAccess(tabId);
    }

    return { ok: false, reason: "Unknown request." };
  })()
    .then(sendResponse)
    .catch((error) => {
      sendResponse({ ok: false, reason: error.message });
    });

  return true;
});
